import React from 'react'
import '../../styles/testimonials.css'
import tt1 from '../../assets/tt1.png'
import tt2 from '../../assets/tt2.png'
import tt3 from '../../assets/tt3.png'
import tt4 from '../../assets/tt4.png'

const testimonials = [
  {
    imgSrc: tt1,
    imgAlt: "Testimonial 1",
    ttComment: "Italians are the best",
    ttName: "Annie",
  },
  {
    imgSrc: tt2,
    imgAlt: "Testimonial 2",
    ttComment: "Best taste, Number one!",
    ttName: "John",
  },
  {
    imgSrc: tt3,
    imgAlt: "Testimonial 3",
    ttComment: "I feel at home.",
    ttName: "Summer",
  },
  {
    imgSrc: tt4,
    imgAlt: "Mascotte 1",
    ttComment: "Bau Bau, Woof Woof !!!",
    ttName: "Fido",
  },
];

export default function Testimonials() {
  return (
        <section id='testimonials'>
          <h4>Testimonials</h4>
          <div id='tts'>
            {testimonials && testimonials.map(testimonial => (
              <div key={testimonial.imgSrc}>
                <div>
                  <p className='rating'>*****</p>
                  <img src={testimonial.imgSrc} alt={testimonial.imgAlt} />
                  <p>{testimonial.ttComment}</p>
                </div>
                <p className='name'>{testimonial.ttName}</p>
              </div>
            ))}
          </div>
        </section>
  )
}
